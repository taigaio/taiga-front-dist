Currently, PRIMARY AUTHORS are:

- Carlos Goce <carlos.goce@revelio.dev>
- Carlos Letamendia <carlos.letamendia@revelio.dev>
- David Barragán Merino <dbarragan@dbarragan.com>
- Daniel Herrero <daniel.herrero@kaleidos.net>
- Juanfran Alcántara <juanfran.alcantara@kaleidos.net>
- Miguel González <miguel.gonzalez@revelio.dev>
- Miryam González <miryam.gonzalez@kaleidos.net>
- Natacha Menjibar <natacha.menjibar@kaleidos.net>
- Pablo Ruiz <pablo.ruiz@kaleidos.net>
- Ramiro Sánchez <ramiro.sanchez@kaleidos.net>
- Teresa de la Torre <teresa.delatorre@kaleidos.net>
- Xavi Julian <xavier.julian@kaleidos.net>
- Yamila Moreno <yamila.moreno@kaleidos.net>

Other previous core team members:

- Alejandro Alonso <alejandro.alonso@kaleidos.net>
- Alex Hermida <alexhermida@gmail.com>
- Andrey Antukh <niwi@niwi.nz>
- Anler Hernández <hello@anler.me>
- Daniel García <dangarbar@gmail.com>
- Esther Moreno <esther.moreno@kaleidos.net>
- Jesus Espino Garcia <jespinog@gmail.com>

Special thanks to `Kaleidos Open Source S.L. <https://kaleidos.net/>`_ for providing time for Taiga development.
